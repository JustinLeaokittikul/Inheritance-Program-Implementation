public class VehicleTester {
    public static void main(String[] args) {
        Vehicle bike = new Vehicle("Bike", 15);
        Car car = new Car("Sedan", 60, 80);

        bike.move(); 
        car.move();  
    }
}