class Car extends Vehicle {
    private int fuelLevel;

    public Car(String name, int speed, int fuelLevel) {
        super(name, speed); 
        this.fuelLevel = fuelLevel;
    }

    @Override
    public void move() {
        System.out.println(name + " is driving at " + speed + " mph with fuel level: " + fuelLevel + "%.");
    }
}